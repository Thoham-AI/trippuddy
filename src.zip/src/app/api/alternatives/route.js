// src/app/api/alternatives/route.js
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import OpenAI from "openai";

export async function POST(req) {
  try {
    const client = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });

    const { activity, location } = await req.json();

    const prompt = `
User is visiting: ${activity?.title || ""}
Location: ${location?.name || ""}, ${location?.country || ""}

Suggest 3–5 alternative places nearby that match the same mood or purpose.
For each alternative, give:
- Name
- 1-sentence description
- Why it's a good alternative
Return ONLY bullet points.
`;

    const res = await client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are a local travel expert." },
        { role: "user", content: prompt },
      ],
      temperature: 0.8,
      max_tokens: 500,
    });

    return NextResponse.json({
      ok: true,
      text: res.choices[0]?.message?.content || "",
    });
  } catch (err) {
    console.error("ALTERNATIVES ROUTE ERROR:", err);
    return NextResponse.json(
      { ok: false, text: "Error getting alternatives." },
      { status: 500 }
    );
  }
}
